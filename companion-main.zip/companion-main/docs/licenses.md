# Licenses

* Companion is distributed under the [Attribution-NonCommercial 4.0 International](https://github.com/shakedzy/companion/blob/main/LICENSE) license.
* Default user image by Font Awesome Free 5.2.0 by [@fontawesome](https://fontawesome.com). White background added by me. 
