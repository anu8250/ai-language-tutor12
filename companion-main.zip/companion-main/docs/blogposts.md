# Related Blogposts

* [How I Coded My Own Private French Tutor Out of ChatGPT](https://shakedzy.medium.com/how-i-coded-my-own-private-french-tutor-out-of-chatgpt-16b3e15007bb)
* [7 Lessons Learned on Creating a Complete Product Using ChatGPT](https://shakedzy.medium.com/7-lessons-learned-on-creating-a-complete-product-using-chatgpt-462038856c85)

<br>
<center>
    <img src="../images/reading_robot.jpg">
</center>